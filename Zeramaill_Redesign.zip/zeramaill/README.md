# Zeramaill (เว็บทางการ)

ไซต์ static (HTML/CSS/JS) ไม่ต้อง build เปิด `index.html` ผ่านเว็บเซิร์ฟเวอร์ใดก็ได้ (เช่น `npx serve .` หรือ `python3 -m http.server`)

ไม่มีข้อมูลตัวอย่าง รีวิวสมมติ เครื่องคิดราคา หรือปุ่มทดลอง การส่งรายการและตรวจสถานะทำงานผ่าน API ของคุณ

## เชื่อมต่อระบบหลังบ้าน

แก้ `config.js` ใส่ `apiBase` ถ้ายังว่าง ฟอร์มจะแจ้งผู้ใช้ว่าระบบยังไม่เปิดให้บริการ (ไม่มีการบันทึกข้อมูลปลอมในเบราว์เซอร์)

`POST {apiBase}/submissions`
```json
{"emails":["a@gmail.com"],"age":"unknown|new|medium|old","method":"promptpay|bank","contact":"..."}
```
ตอบ `201 {"id":"ZM-20261111-AB12"}` ข้อผิดพลาด: `409` (ซ้ำ), `429` (ส่งบ่อยเกินไป), `4xx {"message":"ข้อความภาษาไทย"}`

`GET {apiBase}/submissions/{id}`
```json
{"id":"ZM-...","status":"reviewing|offered|accepted|paid|rejected|cancelled","emailCount":1,"unitPrice":null,
 "events":{"sent":"ISO","reviewing":"ISO","offered":"ISO","accepted":"ISO","paid":"ISO"}}
```
ตอบ `404` เมื่อไม่พบ

หลังบ้านต้องตรวจความเป็นเจ้าของ จำกัดอัตราการเรียก และไม่เก็บรหัสผ่าน/OTP ตรวจสอบเงื่อนไขและนโยบายความเป็นส่วนตัวใน `app.js` กับฝ่ายกฎหมายก่อนเปิดใช้งาน และใส่อีเมลติดต่อใน `config.js`

ฟอนต์: Inter (ดู `licenses/Inter-OFL.txt`) และ Noto Sans Thai
