// ตั้งค่าการเชื่อมต่อระบบหลังบ้าน (ดูรายละเอียดใน README.md)
// apiBase: ที่อยู่ API ของคุณ เช่น "https://api.example.com/v1"
window.ZERAMAILL_CONFIG = {
  apiBase: "",
  maxEmailsPerRequest: 10,
  supportEmail: ""
};
