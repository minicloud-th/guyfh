(() => {
  'use strict';
  const cfg = Object.assign({apiBase: '', maxEmailsPerRequest: 10, supportEmail: ''}, window.ZERAMAILL_CONFIG || {});
  const $ = (s, r = document) => r.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  const apiBase = String(cfg.apiBase || '').replace(/\/+$/, '');

  const STATUS = {
    reviewing: 'รอตรวจสอบ', offered: 'รอยืนยันราคา', accepted: 'รอโอนเงิน',
    paid: 'โอนเงินสำเร็จ', rejected: 'ไม่ผ่านการตรวจสอบ', cancelled: 'ยกเลิกแล้ว'
  };
  const STAGES = [['sent', 'ส่งรายการแล้ว'], ['reviewing', 'ตรวจสอบ'], ['offered', 'แจ้งราคา'], ['accepted', 'ยืนยันราคา'], ['paid', 'โอนเงิน']];
  const dateFmt = new Intl.DateTimeFormat('th-TH', {dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Bangkok'});

  $('#year').textContent = new Date().getFullYear();
  document.querySelectorAll('[data-max]').forEach(n => n.textContent = cfg.maxEmailsPerRequest);
  if (cfg.supportEmail) $('#support-link').href = 'mailto:' + cfg.supportEmail;

  /* ---------- Email handling ---------- */
  const parseEmails = v => v.split(/[\s,;]+/).map(s => s.trim()).filter(Boolean);
  const canonical = e => e.toLowerCase().split('@')[0].split('+')[0].replace(/\./g, '') + '@gmail.com';
  const GMAIL = /^[a-z0-9][a-z0-9._%+\-]{0,63}@gmail\.com$/i;

  const form = $('#submit');
  const emailsEl = $('#emails');
  const countEl = $('#emails-count');
  const statusEl = $('#form-status');
  const btn = $('#submit-btn');

  emailsEl.addEventListener('input', () => {
    const n = parseEmails(emailsEl.value).length;
    countEl.textContent = `${n} อีเมล`;
  });

  function setError(id, msg) {
    const p = $('#' + id + '-error');
    p.textContent = msg || '';
    const field = p.closest('.field') || p.previousElementSibling;
    field?.classList?.toggle('invalid', !!msg);
  }

  function validate() {
    ['emails', 'contact', 'consent'].forEach(k => setError(k, ''));
    const emails = parseEmails(emailsEl.value);
    let first = null;
    const fail = (id, msg, el) => { setError(id, msg); first = first || el; };

    if (!emails.length) fail('emails', 'กรอกอีเมล @gmail.com อย่างน้อย 1 อีเมล', emailsEl);
    else if (emails.length > cfg.maxEmailsPerRequest) fail('emails', `ส่งได้สูงสุด ${cfg.maxEmailsPerRequest} อีเมลต่อครั้ง ตอนนี้มี ${emails.length} อีเมล`, emailsEl);
    else {
      const bad = emails.find(e => !GMAIL.test(e));
      if (bad) fail('emails', `รูปแบบไม่ถูกต้อง: ${bad} (รับเฉพาะ @gmail.com)`, emailsEl);
      else if (new Set(emails.map(canonical)).size !== emails.length) fail('emails', 'มีอีเมลซ้ำในรายการ รวมถึงอีเมลที่ต่างกันเพียงจุดหรือเครื่องหมาย +', emailsEl);
    }
    const contact = $('#contact').value.trim();
    if (contact.length < 3) fail('contact', 'กรอกช่องทางติดต่อกลับ เพื่อให้เราแจ้งราคาได้', $('#contact'));
    if (/(password|passcode|otp|รหัสผ่าน|รหัส otp)/i.test(contact)) fail('contact', 'ช่องนี้ใช้สำหรับช่องทางติดต่อเท่านั้น อย่าใส่รหัสผ่านหรือ OTP', $('#contact'));
    if (!$('#consent').checked) fail('consent', 'ยืนยันความเป็นเจ้าของและยอมรับเงื่อนไขก่อนส่ง', $('#consent'));
    first?.focus();
    return first ? null : {emails, contact, age: $('#age').value, method: $('#method').value};
  }

  async function api(path, options) {
    if (!apiBase) {
      const e = new Error('not-configured');
      e.code = 'not-configured';
      throw e;
    }
    const res = await fetch(apiBase + path, Object.assign({headers: {'Content-Type': 'application/json', Accept: 'application/json'}}, options));
    let data = null;
    try { data = await res.json(); } catch (_) { /* ignore */ }
    if (!res.ok) {
      const e = new Error((data && data.message) || 'request-failed');
      e.status = res.status;
      throw e;
    }
    return data;
  }

  const unavailable = 'ระบบรับรายการยังไม่เปิดให้บริการในขณะนี้ กรุณากลับมาใหม่ภายหลัง';

  form.addEventListener('submit', async event => {
    event.preventDefault();
    statusEl.className = 'status';
    statusEl.textContent = '';
    const payload = validate();
    if (!payload) return;
    btn.disabled = true;
    btn.textContent = 'กำลังส่ง…';
    try {
      const data = await api('/submissions', {method: 'POST', body: JSON.stringify(payload)});
      showDone(data.id, payload.emails.length);
    } catch (err) {
      statusEl.className = 'status err';
      statusEl.textContent = err.code === 'not-configured' ? unavailable
        : err.status === 409 ? (err.message === 'request-failed' ? 'มีอีเมลในรายการนี้อยู่ในระบบแล้ว' : err.message)
        : err.status === 429 ? 'ส่งบ่อยเกินไป กรุณารอสักครู่แล้วลองอีกครั้ง'
        : (err.message && err.message !== 'request-failed' && err.status < 500) ? err.message
        : 'ส่งรายการไม่สำเร็จ ข้อมูลของคุณยังอยู่ในฟอร์ม กรุณาลองอีกครั้ง';
    } finally {
      btn.disabled = false;
      btn.textContent = 'ส่งให้ประเมินราคา';
    }
  });

  function showDone(id, n) {
    const wrap = document.createElement('div');
    wrap.className = 'card form done';
    wrap.id = 'submit';
    wrap.setAttribute('tabindex', '-1');
    wrap.innerHTML = `<h2>ส่งรายการเรียบร้อย</h2>
      <p>รับ ${n} อีเมลเข้าสู่การตรวจสอบแล้ว เก็บเลขรายการนี้ไว้เพื่อติดตามสถานะ</p>
      <p class="ref" id="ref-id">${esc(id)}</p>
      <button type="button" class="btn btn-solid" id="copy-ref">คัดลอกเลขรายการ</button>
      <button type="button" class="link" id="again">ส่งอีเมลเพิ่ม</button>`;
    form.replaceWith(wrap);
    wrap.focus();
    $('#copy-ref').addEventListener('click', async e => {
      try { await navigator.clipboard.writeText(id); e.target.textContent = 'คัดลอกแล้ว'; }
      catch (_) { e.target.textContent = 'คัดลอกไม่ได้ กรุณาเลือกข้อความด้านบน'; }
    });
    $('#again').addEventListener('click', () => location.reload());
    $('#track-id').value = id;
  }

  /* ---------- Tracking ---------- */
  const trackForm = $('#track-form');
  const trackOut = $('#track-result');
  trackForm.addEventListener('submit', async event => {
    event.preventDefault();
    const id = $('#track-id').value.trim().toUpperCase();
    if (!/^ZM-[A-Z0-9-]{4,32}$/.test(id)) {
      trackOut.innerHTML = '<p class="error" role="alert">เลขรายการไม่ถูกต้อง ต้องขึ้นต้นด้วย ZM- เช่น ZM-20261111-AB12</p>';
      $('#track-id').focus();
      return;
    }
    trackOut.innerHTML = '<p>กำลังตรวจสอบ…</p>';
    try {
      const r = await api('/submissions/' + encodeURIComponent(id));
      const events = r.events || {};
      const reached = STAGES.filter(([k]) => events[k]);
      const items = STAGES.map(([k, label]) => {
        const at = events[k];
        return `<li class="${at ? 'done-step' : ''}"><span>${esc(label)}${at ? ' · ' + esc(dateFmt.format(new Date(at))) : ''}</span></li>`;
      }).join('');
      const offer = r.unitPrice != null ? `<div class="row"><span>ราคาที่เสนอ</span><strong>฿${Number(r.unitPrice).toLocaleString('th-TH')} ต่ออีเมล</strong></div>` : '';
      trackOut.innerHTML = `<div class="card result"><div class="row"><strong>${esc(r.id || id)}</strong><span class="badge">${esc(STATUS[r.status] || r.status)}</span></div>
        ${r.emailCount != null ? `<div class="row"><span>จำนวนอีเมล</span><strong>${esc(r.emailCount)}</strong></div>` : ''}${offer}
        <ol class="timeline">${items}</ol></div>`;
    } catch (err) {
      trackOut.innerHTML = `<p class="error" role="alert">${esc(
        err.code === 'not-configured' ? unavailable
        : err.status === 404 ? 'ไม่พบเลขรายการนี้ ตรวจสอบตัวอักษรอีกครั้ง'
        : 'ตรวจสอบสถานะไม่สำเร็จ กรุณาลองอีกครั้ง')}</p>`;
    }
  });

  /* ---------- Policies ---------- */
  const POLICIES = {
    terms: ['เงื่อนไขการใช้งาน', `
      <h3>การส่งรายการ</h3><p>คุณต้องเป็นเจ้าของที่อยู่อีเมลที่ส่งเข้ามา และต้องมีอายุตามที่กฎหมายกำหนดสำหรับการทำธุรกรรม</p>
      <h3>ข้อมูลที่ห้ามส่ง</h3><p>ห้ามส่งรหัสผ่าน รหัส OTP หรือข้อมูลกู้คืนบัญชีในทุกช่องทาง ทีมงานจะไม่ขอข้อมูลเหล่านี้</p>
      <h3>ราคาและการยืนยัน</h3><p>ราคาที่เสนอใช้ได้ตามที่ระบุในข้อเสนอเท่านั้น และจะมีผลเมื่อคุณยืนยันด้วยตนเอง คุณปฏิเสธข้อเสนอได้โดยไม่มีค่าใช้จ่าย</p>
      <h3>การปฏิเสธรายการ</h3><p>เราอาจปฏิเสธรายการที่ไม่ผ่านการตรวจสอบ และจะแจ้งผลผ่านช่องทางติดต่อที่คุณให้ไว้</p>`],
    privacy: ['นโยบายความเป็นส่วนตัว', `
      <h3>ข้อมูลที่เก็บ</h3><p>ที่อยู่อีเมลที่ส่งเข้ามา อายุอีเมลโดยประมาณ ช่องทางติดต่อกลับ และช่องทางรับเงินที่คุณเลือก</p>
      <h3>วัตถุประสงค์</h3><p>ใช้เพื่อตรวจสอบและประเมินราคา ติดต่อแจ้งผล และโอนเงินเมื่อคุณยืนยันราคาแล้วเท่านั้น</p>
      <h3>ข้อมูลที่เราไม่เก็บ</h3><p>เราไม่เก็บรหัสผ่าน รหัส OTP หรือข้อมูลกู้คืนบัญชีของคุณ</p>
      <h3>สิทธิของคุณ</h3><p>คุณขอเข้าถึง แก้ไข หรือลบข้อมูลของคุณได้ตามกฎหมายคุ้มครองข้อมูลส่วนบุคคล โดยติดต่อผ่านช่องทางที่ระบุในหน้านี้</p>`]
  };
  const dialog = $('#dialog');
  document.addEventListener('click', e => {
    const p = e.target.closest('[data-policy]');
    if (p) {
      const [title, body] = POLICIES[p.dataset.policy];
      $('#dialog-title').textContent = title;
      $('#dialog-content').innerHTML = body;
      dialog.showModal();
      return;
    }
    if (e.target.closest('[data-close]') || e.target === dialog) dialog.close();
  });
})();
